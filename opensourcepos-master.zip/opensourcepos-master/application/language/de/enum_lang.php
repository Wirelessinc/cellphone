<?php 

$lang["enum_half_down"] = "Halbe abrunden";
$lang["enum_half_even"] = "Halbe symmetrisch gerade runden";
$lang["enum_half_five"] = "";
$lang["enum_half_odd"] = "Halbe symmetrisch ungerade runden";
$lang["enum_half_up"] = "Halbe aufrunden";
$lang["enum_round_down"] = "Abrunden";
$lang["enum_round_up"] = "Aufrunden";
