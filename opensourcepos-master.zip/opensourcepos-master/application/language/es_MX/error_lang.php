<?php 

$lang["error_no_permission_module"] = "No tienes permiso para acceder el módulo llamado";
$lang["error_unknown"] = "Error inesperado";
