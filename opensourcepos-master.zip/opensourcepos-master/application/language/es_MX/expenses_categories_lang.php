<?php 

$lang["category_name_required"] = "Nombre requerido";
$lang["expenses_categories_add_item"] = "Agregar categoría";
$lang["expenses_categories_cannot_be_deleted"] = "No se puede eliminar la Categoría de Gastos";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "Esta seguro de eliminar la categoría de gasto seleccionada?";
$lang["expenses_categories_confirm_restore"] = "Está seguro que quiere restaurar la categoría de gasto seleccionada?";
$lang["expenses_categories_description"] = "Descripción de Categoría";
$lang["expenses_categories_error_adding_updating"] = "Error al Agregar/Actualizar Categoría de Gastos";
$lang["expenses_categories_info"] = "Información de la Categoría de Gastos";
$lang["expenses_categories_name"] = "Nombre de Categoría";
$lang["expenses_categories_new"] = "Nueva Categoría";
$lang["expenses_categories_no_expenses_categories_to_display"] = "No hay categorías para mostrar";
$lang["expenses_categories_none_selected"] = "No haz seleccionado ninguna categoría de gastos";
$lang["expenses_categories_one_or_multiple"] = "Categoría de Gastos";
$lang["expenses_categories_quantity"] = "Cantidad";
$lang["expenses_categories_successful_adding"] = "Se añadió correctamente la categoría de gastos";
$lang["expenses_categories_successful_deleted"] = "Se eliminó correctamente la categoría de gastos";
$lang["expenses_categories_successful_updating"] = "Se actualizó correctamente la categoría de gastos";
$lang["expenses_categories_update"] = "Actualizar Categoria";
