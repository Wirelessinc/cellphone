<?php 

$lang["datepicker_all_time"] = "همیشه";
$lang["datepicker_apply"] = "درخواست دادن";
$lang["datepicker_cancel"] = "لغو";
$lang["datepicker_custom"] = "سفارشی";
$lang["datepicker_from"] = "از جانب";
$lang["datepicker_last_30"] = "30 روز گذشته";
$lang["datepicker_last_7"] = "آخرین 7 روز";
$lang["datepicker_last_financial_year"] = "آخرین سال مالی";
$lang["datepicker_last_month"] = "ماه گذشته";
$lang["datepicker_last_year"] = "سال گذشته";
$lang["datepicker_same_month_last_year"] = "ماه مشابه سال گذشته";
$lang["datepicker_same_month_to_same_day_last_year"] = "ماه مشابه سال گذشته";
$lang["datepicker_this_financial_year"] = "سال مالی فعلی";
$lang["datepicker_this_month"] = "ماه جاری";
$lang["datepicker_this_year"] = "سال فعلی";
$lang["datepicker_to"] = "به";
$lang["datepicker_today"] = "امروز";
$lang["datepicker_today_last_year"] = "امروز سال گذشته";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "دیروز";
