<?php 

$lang["suppliers_account_number"] = "Broj računa";
$lang["suppliers_agency_name"] = "Naziv agencije";
$lang["suppliers_cannot_be_deleted"] = "Brisanje izabranih dobavljača nije uspjelo. Jedan ili više njih imaju prodaju.";
$lang["suppliers_category"] = "Kategorija";
$lang["suppliers_company_name"] = "Dobavljač";
$lang["suppliers_company_name_required"] = "Dobavljač je obavezan.";
$lang["suppliers_confirm_delete"] = "Da li ste sigurni da želite da izbrišete izabranog dobavljača?";
$lang["suppliers_confirm_restore"] = "Da li ste sigurni da želite vratiti izabranog dobavljača?";
$lang["suppliers_cost"] = "Trošak dobavljača";
$lang["suppliers_error_adding_updating"] = "Ažuriranje ili dodavanje dobavljača nije uspjelo";
$lang["suppliers_goods"] = "Roba dobavljača";
$lang["suppliers_new"] = "Novi dobavljač";
$lang["suppliers_none_selected"] = "Niste izabrali nijednog dobavljača za brisanje";
$lang["suppliers_one_or_multiple"] = "Dobavljač(i)";
$lang["suppliers_successful_adding"] = "Uspješno ste dodali dobavljača";
$lang["suppliers_successful_deleted"] = "Uspješno ste Izbrisali dobavljača";
$lang["suppliers_successful_updating"] = "Uspješno ste ažurirali dobavljača";
$lang["suppliers_supplier"] = "Dobavljač";
$lang["suppliers_supplier_id"] = "ID";
$lang["suppliers_tax_id"] = "Porez Id";
$lang["suppliers_update"] = "Ažuriranje dobavljača";
