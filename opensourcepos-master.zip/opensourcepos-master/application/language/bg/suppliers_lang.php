<?php 

$lang["suppliers_account_number"] = "Account Number";
$lang["suppliers_agency_name"] = "Име на агенцията";
$lang["suppliers_cannot_be_deleted"] = "Избраните доставчици не можаха да бъдат изтрити. Един или повече от тях имат продажби.";
$lang["suppliers_category"] = "";
$lang["suppliers_company_name"] = "Име на компанията";
$lang["suppliers_company_name_required"] = "Името на фирмата е задължително поле.";
$lang["suppliers_confirm_delete"] = "Наистина ли искате да изтриете избрания доставчик (и)?";
$lang["suppliers_confirm_restore"] = "Наистина ли искате да възстановите избраните доставчици?";
$lang["suppliers_cost"] = "";
$lang["suppliers_error_adding_updating"] = "Актуализацията или добавянето на доставчик не бе успешно.";
$lang["suppliers_goods"] = "";
$lang["suppliers_new"] = "Нов доставчик";
$lang["suppliers_none_selected"] = "Не сте избрали доставчик (и), който да изтриете.";
$lang["suppliers_one_or_multiple"] = "Доставчик (и)";
$lang["suppliers_successful_adding"] = "Вие успешно добавихте Доставчика";
$lang["suppliers_successful_deleted"] = "Вие успешно изтрихте";
$lang["suppliers_successful_updating"] = "Обновяването на доставчика е успешно";
$lang["suppliers_supplier"] = "Доставчик";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_tax_id"] = "";
$lang["suppliers_update"] = "Актуализиране на доставчик";
