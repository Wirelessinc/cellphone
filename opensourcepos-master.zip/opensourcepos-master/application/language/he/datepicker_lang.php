<?php 

$lang["datepicker_all_time"] = "כל הזמן";
$lang["datepicker_apply"] = "אשר";
$lang["datepicker_cancel"] = "בטל";
$lang["datepicker_custom"] = "מותאם אישית";
$lang["datepicker_from"] = "מ";
$lang["datepicker_last_30"] = "30 ימים אחרונים";
$lang["datepicker_last_7"] = "שבוע אחרון";
$lang["datepicker_last_financial_year"] = "שנת הכספים האחרונה";
$lang["datepicker_last_month"] = "חודש שעבר";
$lang["datepicker_last_year"] = "שנה שעברה";
$lang["datepicker_same_month_last_year"] = "אותו חודש בשנה שעברה";
$lang["datepicker_same_month_to_same_day_last_year"] = "אותו חודש לאותו יום בשנה שעברה";
$lang["datepicker_this_financial_year"] = "שנת הכספים הנוכחית";
$lang["datepicker_this_month"] = "החודש נוכחי";
$lang["datepicker_this_year"] = "השנה הנוכחית";
$lang["datepicker_to"] = "ל";
$lang["datepicker_today"] = "היום";
$lang["datepicker_today_last_year"] = "היום בשנה שעברה";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "אתמול";
