<?php 

$lang["enum_half_down"] = "חצי למטה";
$lang["enum_half_even"] = "חצי שווה";
$lang["enum_half_five"] = "חצי חמש";
$lang["enum_half_odd"] = "חצי מספר אי זוגי";
$lang["enum_half_up"] = "חצי למעלה";
$lang["enum_round_down"] = "לעגל למטה";
$lang["enum_round_up"] = "לעגל למעלה";
