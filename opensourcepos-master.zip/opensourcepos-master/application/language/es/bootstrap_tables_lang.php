<?php
$lang["tables_all"] = "Todas";
$lang["tables_columns"] = "Columnas";
$lang["tables_hide_show_pagination"] = "Ocultar/Mostrar paginación";
$lang["tables_loading"] = "Por favor espere...";
$lang["tables_page_from_to"] = "Mostrando desde {0} hasta {1} - En total {2} resultados";
$lang["tables_refresh"] = "Refrescar";
$lang["tables_rows_per_page"] = "{0} resultados por página";
$lang["tables_toggle"] = "Ocultar/Mostrar";
